;(function ($, window, document, undefined) {
    "use strict";
    $(document).ready(function () {
        /*
         * Creating a waypoint against each section
         * When the section reaches 50% up the page
         * an active class is added 
         */
        $('section').each( function() {
            // cache the section element
            var el      = $(this); 
            // get the id so we can find the nav link it corresponds to
            var el_id   = el.attr("id"); 
            // get the nav link object for our waypoint handler function
            var anchor  = $('a[href="#'+el_id+'"]');        
            //make each section a waypoint
            el.waypoint({
                handler: function(direction) { 
                    //here we make all navlinks inactive
                    $('.nav-link').removeClass('active'); 
                    //now we activate the one we want
                    anchor.toggleClass('active');
                    if("technical_skills" === el_id){
                        $('.chart').toggleClass('active');
                    } 
                },
                offset: '30%'
            });
        });

        $('.chart').each(function(){
            var el   = $(this);
            el.waypoint({
                handler: function (direction) {
                el.toggleClass('active');
                },
                offset: '30%'
            });
        });

        /*  When a.nav-link is clicked,
            we add a graceful scroll effect
            and also toggle the nav active class
        */
        $('.nav-link').click(function () {
            var link = $(this);
            var target = $(this.hash);
            $('html, body').animate(
                {
                    scrollTop: target.offset().top - 60
                },
                {
                    duration: 1000,
                    easing: 'swing',
                    complete: function () {
                        $('.nav-link').removeClass('active');
                        $(link).addClass('active');
                    }
            });
        });    
        /* Adding the "stuck" class to the
        *  nav menu, Waypoints then wraps this 
        *  and we set it to fixed in our CSS
        */
        var sticky = new Waypoint.Sticky({
           element: $('#menu')[0]
        });

        /*
        * Scroll to top handling for footer
        */
        $("#back-to-top").click(function () {
            $("html, body").animate({ scrollTop: 0 }, "slow");
            return false;
        });  
    });
    /*
 * $(window).on('load') only fires after all 
 * images, fonts and elements are in place, 
 * so there will be no FOUC
 */
    $(window).on('load', function () {
        $('.spinner').fadeOut();                    //we fade out the gold discs immediately(it defaults to a 400ms animation)
        $('.loader').delay(400).fadeOut('slow');   //we add a short delay to fade the white loader
        $('body').delay(400).css({                 //The addition of overflow:visible should be used in conjunction with body{overflow:hidden}
            'overflow': 'visible'                   //This will removes scroll bars on an otherwise empty white page, but they return on load.
        });       
    });
}) (jQuery, window, document);


